export const clothing = {
  
};