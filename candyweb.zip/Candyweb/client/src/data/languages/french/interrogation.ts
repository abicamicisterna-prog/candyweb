export const interrogation = {
  
};