export const connectors = {
  
};