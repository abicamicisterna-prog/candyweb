import LanguageCard from "@/components/LanguageCard";
import SpeechPractice from "@/components/SpeechPractice";
import { languages } from "@/data/languages";
import { useParams } from "wouter";
import { Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function LanguagePage() {
  const params = useParams();
  const [showSpeechPractice, setShowSpeechPractice] = useState(false);
  
  // If we have a specific language ID, show just that language
  const selectedLanguageId = params?.id;
  const selectedLanguage = selectedLanguageId ? languages.find(lang => lang.id === selectedLanguageId) : null;

  // Speech practice examples for each language
  const getSpeechExamples = (languageId: string) => {
    const examples: { [key: string]: any[] } = {
      french: [
        { text: "Bonjour, comment allez-vous?", pronunciation: "bon-ZHOOR koh-mahn tah-lay VOO", translation: "Hola, ¿cómo está usted?" },
        { text: "Je m'appelle Marie", pronunciation: "zhuh mah-PELL mah-REE", translation: "Me llamo Marie" },
        { text: "Merci beaucoup", pronunciation: "mer-SEE boh-KOO", translation: "Muchas gracias" },
        { text: "Au revoir", pronunciation: "oh ruh-VWAHR", translation: "Adiós" }
      ],
      italian: [
        { text: "Ciao, come stai?", pronunciation: "CHAH-oh KOH-meh STAH-ee", translation: "Hola, ¿cómo estás?" },
        { text: "Mi chiamo Marco", pronunciation: "mee kee-AH-moh MAR-koh", translation: "Me llamo Marco" },
        { text: "Grazie mille", pronunciation: "GRAH-tsee-eh MEE-leh", translation: "Muchas gracias" },
        { text: "Arrivederci", pronunciation: "ah-ree-veh-DEHR-chee", translation: "Adiós" }
      ],
      portuguese: [
        { text: "Olá, como está?", pronunciation: "oh-LAH KOH-moh ehs-TAH", translation: "Hola, ¿cómo está?" },
        { text: "Meu nome é Ana", pronunciation: "MEH-oo NOH-meh eh AH-nah", translation: "Mi nombre es Ana" },
        { text: "Muito obrigado", pronunciation: "MOOY-toh oh-bree-GAH-doh", translation: "Muchas gracias" },
        { text: "Tchau", pronunciation: "CHAH-oo", translation: "Adiós" }
      ],
      english: [
        { text: "Hello, how are you?", pronunciation: "HEH-loh HOW ar yoo", translation: "Hola, ¿cómo estás?" },
        { text: "My name is John", pronunciation: "my NAYM iz JAHN", translation: "Mi nombre es John" },
        { text: "Thank you very much", pronunciation: "THANK yoo VEH-ree MUCH", translation: "Muchas gracias" },
        { text: "Goodbye", pronunciation: "good-BYE", translation: "Adiós" }
      ],
      russian: [
        { text: "Привет, как дела?", pronunciation: "pree-VEHT kak dee-LAH", translation: "Hola, ¿cómo estás?" },
        { text: "Меня зовут Иван", pronunciation: "mee-NYAH zah-VOOT ee-VAHN", translation: "Me llamo Ivan" },
        { text: "Большое спасибо", pronunciation: "bahl-SHOH-yeh spah-SEE-boh", translation: "Muchas gracias" },
        { text: "До свидания", pronunciation: "dah svee-DAH-nee-yah", translation: "Adiós" }
      ]
    };
    return examples[languageId] || examples.english;
  };
  
  // If we're showing a specific language
  if (selectedLanguage) {
    return (
      <section className="py-20 px-6 relative z-10 min-h-screen">
        <div className="container mx-auto max-w-5xl pt-20">
          <div className="text-center mb-8">
            <Link href="/language-selection" className="text-blue-400 hover:text-blue-300 mb-4 inline-block">
              ← Volver a la selección de idiomas
            </Link>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              {selectedLanguage.name} ({selectedLanguage.nativeName})
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              {selectedLanguage.description}
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-8">
            {/* Grammar Section */}
            <div>
              <div className="flex justify-center space-x-4 mb-6">
                <Button
                  variant={!showSpeechPractice ? "default" : "outline"}
                  onClick={() => setShowSpeechPractice(false)}
                >
                  Gramática
                </Button>
                <Button
                  variant={showSpeechPractice ? "default" : "outline"}
                  onClick={() => setShowSpeechPractice(true)}
                >
                  Práctica de Habla
                </Button>
              </div>

              {!showSpeechPractice ? (
                <LanguageCard language={selectedLanguage} />
              ) : (
                <SpeechPractice
                  languageName={selectedLanguage.name}
                  languageCode={selectedLanguage.id}
                  examples={getSpeechExamples(selectedLanguage.id)}
                />
              )}
            </div>
          </div>
        </div>
      </section>
    );
  }

  // Otherwise show all languages
  return (
    <section className="py-20 px-6 relative z-10 min-h-screen">
      <div className="container mx-auto max-w-7xl pt-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Explora los Idiomas</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Cada idioma tiene su propia personalidad. Descubre gramática básica, vocabulario esencial 
            y frases útiles para empezar tu aventura lingüística.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {languages.map((language) => (
            <LanguageCard key={language.id} language={language} />
          ))}
        </div>
      </div>
    </section>
  );
}
