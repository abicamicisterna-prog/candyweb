import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { insertUserSchema, loginUserSchema, insertGameScoreSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import { sendSubscriptionNotification, sendTestEmail } from "./emailService";

// Session middleware setup
declare module "express-session" {
  interface SessionData {
    userId?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || "your-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true in production with HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Register route
  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "El usuario ya existe" });
      }

      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "El email ya está registrado" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      // Set session
      req.session.userId = user.id;

      res.json({ 
        message: "Usuario registrado exitosamente",
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          isPremium: user.isPremium
        }
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Error al registrar usuario" });
    }
  });

  // Login route
  app.post("/api/login", async (req, res) => {
    try {
      const loginData = loginUserSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(loginData.username);
      if (!user) {
        return res.status(401).json({ message: "Credenciales inválidas" });
      }

      const validPassword = await bcrypt.compare(loginData.password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Credenciales inválidas" });
      }

      req.session.userId = user.id;

      res.json({
        message: "Login exitoso",
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          isPremium: user.isPremium
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Error al iniciar sesión" });
    }
  });

  // Get current user
  app.get("/api/user", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "No autenticado" });
    }

    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }

      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        isPremium: user.isPremium
      });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Error al obtener usuario" });
    }
  });

  // Logout route
  app.post("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Error al cerrar sesión" });
      }
      res.json({ message: "Sesión cerrada exitosamente" });
    });
  });

  // Mercado Pago subscription route
  app.post("/api/create-subscription", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "No autenticado" });
    }

    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }

      // Create Mercado Pago preference for subscription
      const preference = {
        items: [
          {
            title: "CandyWeb Premium - Suscripción Anual",
            description: "Acceso completo a juegos premium y práctica de habla",
            quantity: 1,
            currency_id: "ARS", // Argentine Peso
            unit_price: 500
          }
        ],
        payer: {
          name: user.username,
          email: user.email || "usuario@candyweb.com"
        },
        payment_methods: {
          excluded_payment_methods: [],
          excluded_payment_types: [],
          installments: 12
        },
        back_urls: {
          success: `${req.protocol}://${req.get('host')}/subscription?status=success`,
          failure: `${req.protocol}://${req.get('host')}/subscription?status=failure`,
          pending: `${req.protocol}://${req.get('host')}/subscription?status=pending`
        },
        auto_return: "approved",
        notification_url: `${req.protocol}://${req.get('host')}/api/mercadopago/webhook`,
        metadata: {
          user_id: user.id
        },
        // Alias configuration for receiving payments
        additional_info: {
          payer: {
            first_name: user.username.split(' ')[0] || user.username,
            last_name: user.username.split(' ')[1] || "",
            phone: {
              area_code: "",
              number: ""
            },
            address: {
              street_name: "",
              street_number: null,
              zip_code: ""
            }
          },
          items: [
            {
              id: "premium_subscription",
              title: "CandyWeb Premium",
              description: "Suscripción premium con acceso completo",
              picture_url: `${req.protocol}://${req.get('host')}/logo.png`,
              category_id: "education",
              quantity: 1,
              unit_price: 500
            }
          ],
          shipments: {
            receiver_address: {
              zip_code: "",
              street_name: "",
              street_number: null,
              floor: "",
              apartment: ""
            }
          }
        },
        // Configure payment to go to cami.abi.. alias
        collector_id: "cami.abi.."
      };

      // In production, you would use Mercado Pago SDK:
      // const mercadopago = require('mercadopago');
      // mercadopago.configure({ access_token: process.env.MERCADOPAGO_ACCESS_TOKEN });
      // const response = await mercadopago.preferences.create(preference);

      // Send notification email about new subscription attempt
      const emailSent = await sendSubscriptionNotification({
        userId: user.id,
        username: user.username,
        email: user.email || "No email provided",
        timestamp: new Date().toLocaleString('es-ES', { 
          timeZone: 'America/Argentina/Buenos_Aires',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        amount: 500,
        currency: "ARS"
      });

      if (emailSent) {
        console.log("Subscription notification email sent successfully");
      } else {
        console.error("Failed to send subscription notification email");
      }

      // For now, return a mock response with the preference structure
      res.json({
        id: `mock_preference_${Date.now()}`,
        init_point: "https://www.mercadopago.com.ar/checkout/v1/redirect?pref_id=mock_id",
        sandbox_init_point: "https://sandbox.mercadopago.com.ar/checkout/v1/redirect?pref_id=mock_id",
        preference: preference,
        collector_alias: "cami.abi..",
        message: "Preferencia de pago creada para el alias cami.abi..",
        email_notification: emailSent ? "Email notification sent" : "Email notification failed"
      });
    } catch (error) {
      console.error("Subscription error:", error);
      res.status(500).json({ message: "Error al crear preferencia de pago" });
    }
  });

  // Mercado Pago webhook for payment notifications
  app.post("/api/mercadopago/webhook", async (req, res) => {
    try {
      const { type, data } = req.body;

      if (type === "payment") {
        const paymentId = data.id;
        console.log("Payment notification received:", paymentId);
        
        // In production, you would verify the payment with Mercado Pago API
        // const mercadopago = require('mercadopago');
        // const payment = await mercadopago.payment.findById(paymentId);
        
        // For now, we'll simulate successful payment processing
        if (req.body.metadata && req.body.metadata.user_id) {
          const userId = req.body.metadata.user_id;
          await storage.updateUserPremium(userId, true);
          console.log(`Premium subscription activated for user: ${userId}`);
          
          // Send confirmation email for successful payment
          const user = await storage.getUser(userId);
          if (user) {
            await sendSubscriptionNotification({
              userId: user.id,
              username: user.username,
              email: user.email || "No email provided",
              timestamp: new Date().toLocaleString('es-ES', { 
                timeZone: 'America/Argentina/Buenos_Aires',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              }),
              amount: 500,
              currency: "ARS"
            });
          }
        }
      }

      res.status(200).json({ message: "Webhook processed" });
    } catch (error) {
      console.error("Webhook error:", error);
      res.status(500).json({ message: "Error processing webhook" });
    }
  });

  // Test email endpoint
  app.post("/api/test-email", async (req, res) => {
    try {
      const emailSent = await sendTestEmail();
      
      if (emailSent) {
        res.json({ 
          message: "Email de prueba enviado exitosamente a candyweb44@gmail.com",
          success: true
        });
      } else {
        res.status(500).json({ 
          message: "Error al enviar email de prueba",
          success: false
        });
      }
    } catch (error) {
      console.error("Test email error:", error);
      res.status(500).json({ message: "Error al enviar email de prueba" });
    }
  });

  // Game scores endpoints
  app.post("/api/game-scores", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const scoreData = insertGameScoreSchema.parse(req.body);
      const score = await storage.saveGameScore(req.session.userId, scoreData);
      res.json(score);
    } catch (error) {
      console.error("Error saving game score:", error);
      res.status(500).json({ message: "Failed to save game score" });
    }
  });

  app.get("/api/user-scores", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const scores = await storage.getUserScores(req.session.userId);
      res.json(scores);
    } catch (error) {
      console.error("Error fetching user scores:", error);
      res.status(500).json({ message: "Failed to fetch user scores" });
    }
  });

  app.get("/api/leaderboard/game/:gameId", async (req, res) => {
    try {
      const { gameId } = req.params;
      const limit = parseInt(req.query.limit as string) || 10;
      const leaderboard = await storage.getGameLeaderboard(gameId, limit);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching game leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch game leaderboard" });
    }
  });

  app.get("/api/leaderboard/global", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const leaderboard = await storage.getGlobalLeaderboard(limit);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching global leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch global leaderboard" });
    }
  });

  app.get("/api/user-ranking", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const ranking = await storage.getUserRanking(req.session.userId);
      res.json(ranking);
    } catch (error) {
      console.error("Error fetching user ranking:", error);
      res.status(500).json({ message: "Failed to fetch user ranking" });
    }
  });

  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const { name, email, message } = req.body;
      
      // Here you would typically send an email to candyweb44@gmail.com
      // For now, we'll just log it
      console.log("Contact form submission:", {
        name,
        email,
        message,
        timestamp: new Date().toISOString()
      });

      res.json({ message: "Mensaje enviado exitosamente" });
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(500).json({ message: "Error al enviar mensaje" });
    }
  });

  const httpServer = createServer(app);
  // Suggestions routes
  app.get("/api/suggestions", async (req, res) => {
    try {
      const language = req.query.language as string;
      const userId = req.session?.userId;

      if (language) {
        const suggestions = await storage.getSuggestionsByLanguage(language, userId);
        res.json(suggestions);
      } else {
        const suggestions = await storage.getAllSuggestions(userId);
        res.json(suggestions);
      }
    } catch (error) {
      console.error("Error fetching suggestions:", error);
      res.status(500).json({ message: "Error al obtener sugerencias" });
    }
  });

  app.post("/api/suggestions", async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "No autenticado" });
    }

    try {
      const suggestionData = req.body;
      const suggestion = await storage.createSuggestion(req.session.userId, suggestionData);
      res.json(suggestion);
    } catch (error) {
      console.error("Error creating suggestion:", error);
      res.status(500).json({ message: "Error al crear sugerencia" });
    }
  });

  app.post("/api/suggestions/:id/like", async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "No autenticado" });
    }

    try {
      const suggestionId = req.params.id;
      await storage.likeSuggestion(req.session.userId, suggestionId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error liking suggestion:", error);
      res.status(500).json({ message: "Error al dar like" });
    }
  });

  return httpServer;
}
