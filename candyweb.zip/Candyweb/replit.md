# CandyWeb - Language Learning Platform

## Overview

CandyWeb is an interactive language learning platform inspired by Netflix's user interface. The application provides gamified language learning experiences for multiple languages (French, Italian, Portuguese, English, and Russian) through a variety of mini-games and educational content. Features a beautiful animated blue background with moving orange and yellow orbs. Built as a full-stack web application with a React frontend and Express backend.

**New Premium Features (January 2025):**
- Premium subscription system ($500) with PostgreSQL database integration
- 5 premium games locked for non-subscribers (Las Compras de María and below)
- Speech practice functionality with voice recognition for grammar learning
- Updated support system with social media integration
- Competitive scoring system with global and game-specific leaderboards
- Performance tracking with completion times, difficulty levels, and ranking

**Premium Game Locking System:**
- Games locked: Maria's Shopping, Spiderman Train, Treasure Hunt, Word Soup, Plant Care
- Visual lock overlay with upgrade prompts for non-premium users
- Premium banner encouraging subscription for additional features

**Speech Practice Integration:**
- Web Speech API integration with voice recognition
- Language-specific pronunciation examples and feedback
- Premium-only feature with pronunciation scoring system
- Available in all 5 supported languages with native speech recognition

**Payment Configuration (January 2025):**
- Mercado Pago integration with alias "cami.abi" for payment collection
- $500 ARS pricing for premium subscription
- Webhook endpoint for payment notifications at /api/mercadopago/webhook
- Preference creation with user metadata for subscription activation

**Email Notification System (January 2025):**
- SendGrid integration for automated email notifications
- Subscription alerts sent to candyweb44@gmail.com for each new premium user
- Detailed email templates with user information, payment details, and features unlocked
- Test email functionality for configuration verification
- Automatic notifications on both subscription creation and payment confirmation

**Competitive Scoring System (January 2025):**
- PostgreSQL-based game scores tracking with user performance analytics
- Global leaderboard showing top players across all games with total scores
- Game-specific leaderboards for individual game performance comparison
- Personal score history with completion times, difficulty levels, and language preferences
- Real-time ranking system with user position calculation and statistics
- Score sharing functionality for social engagement
- Integration with all 10 interactive games for comprehensive performance tracking

**Grammar System Expansion (January 2025):**
- Major architectural update transforming from basic 3-tier grammar to university-level comprehensive language learning content
- Complete redesign of Language interface with 20+ detailed linguistic categories per language
- French language fully implemented with extensive content including pronunciation guides, cultural contexts, and advanced grammatical structures
- Italian, Portuguese, English, and Russian languages updated with foundational comprehensive grammar structures
- Educational content equivalent to advanced language learning courses with practical examples and translations

**Comprehensive Alphabet System (January 2025):**
- Complete alphabet implementation for all 5 languages with university-level linguistic detail
- **French**: 26 letters + variations, liaison rules, regional pronunciations, phonetic transcriptions
- **Italian**: 21 native + 5 foreign letters, consonant doubling, stress patterns, regional variations
- **Portuguese**: 26 letters + dígrafos, nasal vowels, Brazilian vs European Portuguese differences
- **English**: 26 letters representing 44+ sounds, spelling patterns, silent letters, regional varieties
- **Russian**: 33 Cyrillic letters, hard/soft consonants, vowel reduction, transliteration systems
- Centralized alphabet management system with lazy loading and detailed linguistic features
- Each alphabet includes pronunciation guides, cultural notes, learning tips, and practical examples

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for development and production builds
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript (ESM modules)
- **Database ORM**: Drizzle ORM
- **Database**: PostgreSQL (configured for Neon Database)
- **Session Storage**: PostgreSQL-based sessions with connect-pg-simple

### Project Structure
- **Monorepo**: Single repository with shared schema and types
- **Frontend**: `/client` directory containing React application
- **Backend**: `/server` directory containing Express API
- **Shared**: `/shared` directory for common types and database schema
- **Build Output**: `/dist` for compiled backend, `/dist/public` for frontend assets

## Key Components

### Authentication System
- User authentication with username/password
- Session-based authentication using PostgreSQL storage
- User schema includes id, username, and password fields

### Language Learning Content
- **Languages**: Support for 5 languages (French, Italian, Portuguese, English, Russian) with native names, flags, and cultural colors
- **Comprehensive Alphabet Systems**: Complete alphabet implementation with detailed linguistic analysis for each language
- **Comprehensive Grammar System** (January 2025 - Major Expansion):
  - **20+ Linguistic Categories**: Complete coverage including greetings/responses, geography (countries/cities/nationalities), detailed pronunciation (consonants, vowels, accents), alphabet systems, articles (definite/indefinite/contracted/partitive), numbers, geometry, colors, time expressions, animals, plants, family structures, profession vocabulary
  - **Advanced Verb Systems**: Complete verb libraries with translations, all tense conjugations (present, past simple/compound/imperfect/pluperfect, future, conditional, subjunctive), auxiliary verbs, imperatives, modal verbs, irregular verb patterns
  - **Comprehensive Pronoun Coverage**: Subject, tonic, reflexive, invariable, direct/indirect object, possessive, demonstrative, interrogative pronouns with usage examples
  - **Material Vocabularies**: School supplies, fabric/clothing materials with detailed characteristics and usage contexts
  - **Temporal Systems**: Formal/colloquial time telling, calendar terms (months/days/seasons), time prepositions, adverbs of frequency
  - **Spatial & Linguistic Elements**: Place/time/movement/manner prepositions, verbal periphrases, weather/food vocabulary, body parts, physical descriptions, clothing/accessories, character traits
  - **Advanced Grammar Structures**: Connectors, negation (basic/advanced), question formation (yes/no, open-ended, response patterns), sentence structures, cultural usage notes
  - **University-Level Content**: Detailed phonetic transcriptions, linguistic rules, grammatical exceptions, cultural contexts, practical examples with translations
  - **French Language**: Fully implemented with all 20+ categories including detailed pronunciation guides, liaison rules, formal/informal registers, and comprehensive cultural notes
- **Vocabulary Systems**: Essential word translations with pronunciation guides
- **Interactive Learning**: Gamified approach to language acquisition with comprehensive grammatical foundations

### Game Engine
- **10 Complete Interactive Games**: 
  1. Football Words - Goal-scoring vocabulary game
  2. Vacation Routine - Daily activity completion
  3. Image Association - Visual-word matching
  4. Snoopy Path - Obstacle course navigation
  5. Fashion Shopping - Character styling game
  6. Maria's Shopping - Grocery shopping simulation
  7. Spiderman Train - Direction-based puzzle
  8. Treasure Hunt - Map-based word discovery
  9. Word Soup - Cultural word search puzzle
  10. Plant Care - Gardening simulation
- **Multi-language Support**: All games available in 5 languages
- **Progress Tracking**: Game completion and achievement systems
- **Gamification**: Confetti effects, scoring, and reward systems

### User Interface
- **Netflix-inspired Design**: Dark theme with gradient backgrounds
- **Animated Background**: Blue background with moving orange/yellow orbs
- **Responsive Design**: Mobile-first approach with desktop optimization
- **Component Library**: Comprehensive UI components for forms, navigation, cards, and interactive elements

## Data Flow

### Client-Server Communication
1. **API Routes**: RESTful endpoints prefixed with `/api`
2. **Request/Response**: JSON-based communication with proper error handling
3. **Session Management**: Automatic session validation and user state persistence
4. **Real-time Feedback**: Immediate game results and progress updates

### Database Operations
1. **User Management**: CRUD operations for user accounts
2. **Progress Tracking**: Game completion and score storage
3. **Session Storage**: Secure session management with PostgreSQL
4. **Schema Evolution**: Database migrations through Drizzle Kit

### State Management
1. **Client State**: React component state for UI interactions
2. **Server State**: TanStack Query for API data caching and synchronization
3. **Form State**: React Hook Form for complex form handling
4. **Global State**: Context providers for user authentication and preferences

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React, React DOM, React Router (Wouter)
- **UI Framework**: Radix UI primitives, Lucide React icons
- **Styling**: Tailwind CSS, PostCSS, Autoprefixer
- **Backend**: Express.js, PostgreSQL drivers
- **Development**: TypeScript, ESBuild, Vite

### Database
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle ORM**: Type-safe database operations
- **Connection Pooling**: Built-in connection management

### Utilities
- **Form Handling**: React Hook Form with Zod validation
- **Date Management**: date-fns for date utilities
- **Styling Utilities**: clsx, class-variance-authority
- **Development Tools**: TSX for TypeScript execution, runtime error overlays

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with HMR
- **Database**: Environment variable configuration for DATABASE_URL
- **Asset Serving**: Vite middleware for static assets and client-side routing

### Production Build
1. **Frontend Build**: Vite builds optimized React application to `/dist/public`
2. **Backend Build**: ESBuild compiles TypeScript server to `/dist`
3. **Database Setup**: Drizzle migrations for schema deployment
4. **Environment Configuration**: Production environment variables for database and sessions

### Hosting Requirements
- **Node.js Environment**: ESM module support required
- **PostgreSQL Database**: Neon Database or compatible PostgreSQL instance
- **Static Asset Serving**: Express serves built frontend from `/dist/public`
- **Environment Variables**: DATABASE_URL for database connection

### Performance Optimizations
- **Code Splitting**: Vite automatically splits code for optimal loading
- **Asset Optimization**: Image optimization and compression
- **Database Queries**: Optimized queries through Drizzle ORM
- **Caching Strategy**: TanStack Query provides intelligent caching